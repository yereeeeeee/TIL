from django.shortcuts import render, redirect
from .models import Diary, Comment
from .forms import DiaryForm, CommentForm

# Create your views here.
def index(request):
    '''
        /index/ 경로로 요청이 왔을 시, index view 함수가 해야 하는 일은
        1. diary들의 모든 정보를 보여 줘야 하고,
        2. 그 각각의 diary들을 참조하고 있는 모든 댓글들도 보여줘야 하고,
            - 댓글들이 각각 삭제 요청 할 수 있는 버튼도 보여줘야 한다.
        3. comment 생성을 위한 form도 사용자에게 보여줘야 한다.
    '''
    diaries = Diary.objects.all()
    '''
        어느 다이어리가 가진 댓글들인지... 복잡하게 생각하지 말고,
        다이어리를 순회해서 사용자에게 보여주려는 그 순간에
        그 다이어리가 가진 댓글들을 보여주면 되는거 아님?
    '''
    # view에서 모든 댓글들을 다 처리하려고 한다면....?
    # 어... 나중에 화면에서 보여줄떄, `댓글 1` 이 어느 diary의 댓글인지 어케암?
    # all_of_comments = []
    # for diary in diaries: # 모든 diary들을 순회해서..
    #     comments = diary.comment_set.all()  # 그 각각의 diary가 가진 댓글들
    #     # 그냥 순서대로 append 해버릴까?
    #     # 지금 당장은 문제 없을지도? 근데... 만약... 정렬을 해야한다면?
    #     # 복잡해 지니까.. 나중에도 찾기 쉽게... dict 형태로 맨들어서
    #     # { diary_id : commetns }
    #     all_of_comments.append({diary.pk : comments})
    # print(all_of_comments)

    
    comment_form = CommentForm()
    context = {
        'diaries': diaries,
        'comment_form': comment_form
    }
    return render(request, 'diaries/index.html', context)

def create(request):
    if request.method == 'POST':
        form = DiaryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('diaries:index')
    else:
        form = DiaryForm()
    context = {
        'form': form
    }
    return render(request, 'diaries/create.html', context)

def comments_create(request, diary_pk):
    # 나중에 저장할 diary 정보 (내가 참조할 모델 정보)가 필요하므로
    # diary_pk도 같이 필요하다 -> url 작성시 variable routing으로 작성
    diary = Diary.objects.get(pk=diary_pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        '''
            form = CommentForm으로 만들어졌고, 
            사용자가 넘긴 데이터를 기반으로 form을 구성했는데...

            그 사용자가 넘긴 데이터는...
            exclude = ('diary')에 의해서.. diary에 대한 정보가 누락

            그럼... 유효성 검사 통과 못해야 하는거 아닐까? 라고 생각 할 수 도 있지만...
            저 유효성 검사라고 하는건... 
            form이 받아야 하는 field들에 담긴 데이터에 대해서만 유효성 검사를 실행
        '''
        # 아래의 is_valid는 무엇만? content만... 검사를한다.
        # 그럼 diary에 들어갈 정보는 비어있는 상태로 DB에 저장하려고 하면?
        # 무결성 에러가 발생할 것이다.
        if form.is_valid():
            '''
                잠시 DB에 반영은 안하지만,
                넘겨받은 데이터를 기반으로 어떠한 객체 하나를 생성하여서
                comment 변수에 담게된다.

                comment.pk = None
                comment.diary = None
                comment.content = request.POST.get('content')
                comment.created_at = request ?? (현재 시간)
                comment.save() -> diary가 비었으니까 무결성 에러
            '''
            comment = form.save(commit=False)
            comment.diary = diary   # class에서 설명한 객체 자체를 할당하는 부분
            comment.save()
    return redirect('diaries:index')

def comments_delete(request, comment_pk):
    comment = Comment.objects.get(pk=comment_pk)
    comment.delete()
    return redirect('diaries:index')