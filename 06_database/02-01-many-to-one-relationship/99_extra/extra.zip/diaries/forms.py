from django import forms
from .models import Diary, Comment


class DiaryForm(forms.ModelForm):

    class Meta:
        model = Diary
        fields = '__all__'

class CommentForm(forms.ModelForm):
    '''
        1번 다이어리에 댓글을 달려고 하는데
        댓글 달려고 할때 몇번 다이어리에 다는 댓글인지를 
        사용자가 선택하는건 이상하니까 diary 컬럼을 제외한다.

        지금 상황상, 이상한 경우라서 diary를 제외하는거지,
        어떠한 경우에는 diary 같은 내가 참조하고있는 
        1이 되는 모델을 사용자가 직접 선택해야하는 경우도 있을 수 있다.

        category = [음식, 영화, 만화, 게임, 공부]
        article = [제목, 내용, 카테고리]
        위와 같은 경우, category article이 1: N 관계일 때,
        글을 작성하는 작성자 (user)가 글 작성시
        나의 글의 카테고리가 무엇인지 직접 선택 할 수도 있겠다.
    '''
    class Meta:
        model = Comment
        # fields = '__all__'
        # fields = ('content',)
        exclude = ('diary',)