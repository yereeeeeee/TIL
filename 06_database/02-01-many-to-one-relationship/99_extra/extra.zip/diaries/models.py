from django.db import models

# Create your models here.
class Diary(models.Model):
    content = models.CharField(max_length=125)
    picture = models.ImageField(blank=True, upload_to='diary/%y/%b/%a')
    created_at = models.DateTimeField(auto_now_add=True)

'''
    SQL -> CREATE TABLE diaries_comment ( column_name_1 Data Type...)
    django -> class 

    Comment가 참조할 대상인 diary의 어떤 정보를  comment table에 저장했는가?
    참조할 대상 dirary 레코드 (하나의 데이터)가 가진 pk 정보를 저장할 공간
        - 해당 컬럼 (필드) 명은 diary_id (id가 저장될 공간이니까) 라는 형식으로 만들었었다.
            -> 정수가 들어갈 것이고, 여기에 들어가는 데이터는 diary의 id 값을 담을거야.

    django Comment 테이블이 참조할 대상 diary에 대한 정보르 저장할 공간
        diary 필드의 변수 명을 diary (참조할 대상의 model 명의 소문자)
            -> django의 Comment 클래스에 정의한 diary 필드는? 왜 diary인가?
            diary 객체 자체를 여기에 담아서 쓸 수 있도록 하겠다.

            -> 만약, django class에서도 Comment의 diary_id 라는곳에 참조 대상 id만 삽입한다면?
            특정 댓글 하나가 참조하고 있는 diary의 정보를 얻고 싶다면?

            comment_diary = Diary.objects.get(pk = comment.diary_id) (1, 2, ... 이런 정수들...)
            comment_diary.content

            -> 위 방식은 너무 불편해. 그래서 django가 알아서 Comment의 인스턴스에게는..
            comment.diary -> 내가 참조하고 있는 diary 객체 정보를 그대로 담아준다.

            comment.diary.content 이렇게 바로 접근 할 수 있도록 만들어준다.
                (모델 명을 소문자로 적어서 필드로 만드는 이유?)
                -> 그냥 파이썬에서 변수명은 전부 소문자로 쓰니까...

    저장하는 공간에 무엇을 저장할 것인가를 생각해보면 둘의 차이를 이해하기 쉽다.

'''
class Comment(models.Model):
    # 만약 필드명을 diary_id 라고 지었다면, 코드가 안돌아가는 것 아님!!
    # 대신, 아래 처럼 뭔가.... 뭔가 이상한 모양새가 될 수 있음
    # comment.diary_id.content  (id는 INT인데 어떻게 content를 가짐?)

    '''
        왜래키를 정의한다?
        내가 참조할 대상의 id나 그와 유사한 고유값을 내 테이블에 저장하겠다.
            -> `내가 참조할 대상`
        당연히, 외래 키를 정의 하려면? 내가 참조할 대상도 같이 알려줘야 한다.
        그래서 ForeignKey(to=Diary)와 같은 형식으로 작성 할 수 있는 이유는 뭐냐?
        위에서 이미 Diary class를 정의해 놨기 때문이다.

            print(dust)
            dust = 60

            파이썬 문법으로 불가능한 행위
        어... 그러면... 만약 class가 엄청 많아지고,
        그 많은 테이블들이 막 복잡하게 관계가 얽혀있다면? 어떻게 하지
    '''
    diary = models.ForeignKey(Diary, on_delete=models.CASCADE)
    content = models.CharField(max_length=125)
    created_at = models.DateTimeField(auto_now_add=True)